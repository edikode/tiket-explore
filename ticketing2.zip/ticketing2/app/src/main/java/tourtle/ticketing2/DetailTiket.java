package tourtle.ticketing2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.alkaaf.btprint.BluetoothPrint;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import tourtle.ticketing2.utils.Session;

public class DetailTiket extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private String print,namaWisata;
    private String hari,jam;
    private String idTiket;
    private Integer jumlahOrang = 0;
    private Integer jumlahKendaraan = 0;
    private Integer biayaTiket = 0;
    private Integer biayaParkir = 0;
    private Integer totalBiaya = 0;
    private Integer hargaTiket = 0;
    private Integer parkir = 0;
    private Integer z = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_tiket);

        final Session session = new Session(getApplicationContext());

        Bundle bundle = getIntent().getExtras();
        mDatabase = FirebaseDatabase.getInstance().getReference("tiket");
        idTiket = bundle.getString("idTiket");
        jumlahOrang = bundle.getInt("jumlahOrang");
        jumlahKendaraan = bundle.getInt("jumlahKendaraan");
        biayaTiket = bundle.getInt("biayaTiket");
        biayaParkir = bundle.getInt("biayaParkir");
        totalBiaya = bundle.getInt("totalBiaya");
        hargaTiket = bundle.getInt("hargaTiket");
        parkir = bundle.getInt("parkir");
        hari = bundle.getString("hari");
        jam = bundle.getString("jam");

        String idNegara = bundle.getString("idNegara");
        print = bundle.getString("print");
        namaWisata = session.getNamaWisata();

        TextView tvJumlahOrang = findViewById(R.id.tvJumlahOrang);
        TextView tvJumlahKendaraan = findViewById(R.id.tvJumlahKendaraan);
        TextView tvBiayaTiket = findViewById(R.id.tvBiayaTiket);
        TextView tvBiayaParkir = findViewById(R.id.tvBiayaParkir);
        TextView tvTotalBiaya = findViewById(R.id.tvTotalBiaya);

        tvJumlahKendaraan.setText(String.valueOf(jumlahKendaraan));
        tvJumlahOrang.setText(String.valueOf(jumlahOrang));
        tvBiayaParkir.setText(String.valueOf(biayaParkir));
        tvBiayaTiket.setText(String.valueOf(biayaTiket));
        tvTotalBiaya.setText(String.valueOf(totalBiaya));

        Button btnPrint = findViewById(R.id.btnPrint);

        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        Calendar c = Calendar.getInstance();
        String date2 = dateFormat.format(c.getTime());

        Date date1 = null;
        try {
            date1 = dateFormat.parse(jam);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Date date3 = null;
        try {
            date3 = dateFormat.parse(date2);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        long difference = date3.getTime() - date1.getTime();

        Integer days = (int) (difference / (1000*60*60*24));
        Integer hours = (int) ((difference - (1000*60*60*24*days)) / (1000*60*60));
        final Integer min = (int) (difference - (1000*60*60*24*days) - (1000*60*60*hours)) / (1000*60);

        btnPrint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if (min>5){
                Toast.makeText(DetailTiket.this, "Maaf, data sudah lebih dari 5 menit.", Toast.LENGTH_SHORT).show();
            }else{
                if (print.equals("1")) {
                    Toast.makeText(DetailTiket.this, "Maaf tiket sudah di print", Toast.LENGTH_SHORT).show();
                } else {
                    DecimalFormat decimalFormat = new DecimalFormat("#,##0" +
                            "");
                    mDatabase.child(idTiket).child("print").setValue("1");
                    z++;
                    if (z>=2){
                        Toast.makeText(DetailTiket.this, "Maaf sudah diprint", Toast.LENGTH_SHORT).show();
                    }else{
                        BluetoothPrint print = new BluetoothPrint(DetailTiket.this);
                        BluetoothPrint.Builder builder = new BluetoothPrint.Builder(BluetoothPrint.Size.WIDTH58);
                        Bitmap sBitmap = initSponBitmap();
                        builder.addLine();
                        builder.setAlignMid();
                        builder.addTextln(session.getNamaWisata());
                        builder.addLine();
                        builder.setAlignLeft();
                        builder.addFrontEnd("No Transaksi: ", idTiket);
                        builder.addFrontEnd("Tanggal: ", ubahTanggal(hari));
                        builder.addFrontEnd("Jam",jam);
                        builder.addLine();
                        builder.addFrontEnd("Tiket " + jumlahOrang + " x " + hargaTiket + ":", "" + decimalFormat.format(biayaTiket));
                        builder.addFrontEnd("Kendaraan " + jumlahKendaraan + " x " + " " + parkir + ":", "" + biayaParkir);
                        builder.addLine();
                        builder.setAlignRight();
                        builder.addTextln("Total: " + decimalFormat.format(totalBiaya));
                        builder.addTextln("*sudah termasuk asuransi");
                        builder.addLine();
                        builder.addBitmap(sBitmap);

                        BluetoothPrint.with(DetailTiket.this)
                                .autoCloseAfter(0)
                                .setData(builder.getByte())
                                .print();

                    }
                }

            }

            }
        });


    }

    private Bitmap initSponBitmap() {
        int offset = 50;

        Bitmap sponBitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.majestic);

        Bitmap sBitmap = Bitmap.createBitmap(
                sponBitmap.getWidth() + offset * 2, // Width
                sponBitmap.getHeight() + 25 * 2, // Height
                Bitmap.Config.ARGB_8888 // Config
        );

        Canvas canvasSpon = new Canvas(sBitmap);
        canvasSpon.drawColor(Color.WHITE);

        Paint paint = new Paint();
        paint.setColor(Color.BLACK);

        canvasSpon.drawBitmap(
                sponBitmap, // Bitmap
                offset, // Left
                25, // Top
                paint // Paint
        );
        return sBitmap;
    }

    private String ubahTanggal(String tanggal){
        SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy");

        Date newDate = null;
        try {
            newDate = format.parse(tanggal);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        format = new SimpleDateFormat("dd MMM yyyy");
        String date = format.format(newDate);
        return date;
    }


}
